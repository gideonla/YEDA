<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>Выход</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Первый</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Третий</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Язык: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Русский</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Второй</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Изометрический</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Перспектива</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Пример интернациноализации</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
